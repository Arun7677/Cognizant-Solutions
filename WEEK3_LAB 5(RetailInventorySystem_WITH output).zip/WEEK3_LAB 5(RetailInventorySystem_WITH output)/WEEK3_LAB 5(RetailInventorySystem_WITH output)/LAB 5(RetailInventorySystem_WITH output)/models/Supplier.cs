using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using RetailInventorySystem.Models;

namespace RetailInventorySystem.Models
{
    public class Supplier
    {
        [Key]
        public int SupplierId { get; set; }

        public string Name { get; set; } = string.Empty;

        public List<Product> Products { get; set; } = new();
    }
}
